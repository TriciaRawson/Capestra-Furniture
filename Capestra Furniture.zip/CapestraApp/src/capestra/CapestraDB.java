/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capestra;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 *
 * @authors Vincent and Tricia */

  
public class CapestraDB {

    private Statement stmt;
    private Connection connection;

    private void initializeDB() {
        try {
            //load the appropriate driver
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loaded");

            String databaseName = "mydb";
            String databaseUserName = "user";
            String databasePassword = "Password1";

            // Establish a connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + databaseName, databaseUserName, databasePassword);
            System.out.println("Database connected");

            // Create a statement
            stmt = connection.createStatement();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void showEmployee(TextField employeeID_textField, Label status_label) {
        initializeDB();
        String employeeID = employeeID_textField.getText();
        try {
            String queryString = "select firstName, lastName, email from employee where employeeID = '" + employeeID + "' ";
            System.out.println(queryString);
            ResultSet rset = stmt.executeQuery(queryString);
            if (rset.next()) {
                String firstName = rset.getString(1);
                String lastName = rset.getString(2);
                String email = rset.getString(3);
                status_label.setText(firstName + " " + lastName + " : " + email);
            } else {
                status_label.setText("Not found");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        closeDB();
    }

    public void createCustomer(TextField ac_firstName_textField,TextField ac_lastName_textField,
                TextField ac_address_textField,TextField ac_city_textField,TextField ac_state_textField,
                TextField ac_zipCode_textField,
                TextField ac_phone_textField,
                TextField ac_email_textField)
    {initializeDB(); 
    
            String firstName = ac_firstName_textField.getText();
            String lastName = ac_lastName_textField.getText();
            String address = ac_address_textField.getText();
            String city = ac_city_textField.getText();
            String state = ac_state_textField.getText();
            String zipCode = ac_zipCode_textField.getText();
            String phone = ac_phone_textField.getText();
            String email = ac_email_textField.getText();
    
         try {   
            String query = "Insert into customer (firstName, lastName, address, city, state, zipCode, phone, email)values ('?', '?', '?', '?', '?', '?', '?', '?')";
           
           PreparedStatement ps = connection.prepareStatement(query);
           ps.setString(1, firstName);
           ps.setString(2, lastName);
           ps.setString(3, address);
           ps.setString(4, city);
           ps.setString(5, state);
           ps.setString(6, zipCode);
           ps.setString(7, phone);
           ps.setString(8, email);
           
           ps.execute();
                            
         }catch (Exception ex) {
         
          ex.printStackTrace();
            
        
           
            System.out.println(firstName + " "+ lastName + " " + address + " " + city + " " + state
             + " " + zipCode + " " + phone + " " + email);
   
           closeDB(); 
         
         }
    }
        public void createOrder(TextField ad_customerID_textField,
                TextField ad_productID_textField,
                TextField ad_quantity_textField,
                String employeeID,
                Label ad_status_label) {
        initializeDB();
        String customerID = ad_customerID_textField.getText();
        String productID = ad_productID_textField.getText();
        String quantity = ad_quantity_textField.getText();
        
        try {
            
            
            //checking if the customer exists
            String queryString = "select count(*) as customerExists from customer where customerID = '" + customerID + "' ";
            PreparedStatement stmt = connection.prepareStatement(queryString);
            System.out.println(queryString);
            ResultSet rset = stmt.executeQuery(queryString);
            int customerExistsCount=0;
            if (rset.next()) {
                customerExistsCount = rset.getInt(1);
                if (customerExistsCount == 0){
                    ad_status_label.setText("Customer not found, try another");
                    return;
                }
            }
            
            
            //checking if the product exists as well as the quantity available
            queryString = "select productName, quantity from product where productID = '" + productID + "' ";
            stmt = connection.prepareStatement(queryString);
            System.out.println(queryString);
            rset = stmt.executeQuery(queryString);
            int availableQuantity=0;
            String productName="";
            if (rset.next()) {
                productName = rset.getString(1);
                availableQuantity = rset.getInt(2);
                if (availableQuantity == 0){
                    ad_status_label.setText("Product "+productName+" has no quantitity available");
                    return;
                }
                if (availableQuantity < Integer.parseInt(quantity)){
                    ad_status_label.setText("Product "+productName+" only has " + availableQuantity + " available. Please enter in a smaller number");
                    return;
                }
            }
            else{
                 ad_status_label.setText("Product not found, try another");
                 return;
            
            }
            
            
            //setting the autocommit to false
            connection.setAutoCommit(false);
            
            
            //insert into order table
            String query = "insert into `order` (customerID, employeeID, OrderDate) values (?,?, now())";
            PreparedStatement ps = connection.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, customerID);
            ps.setString(2, employeeID);
            System.out.println(query);
            ps.execute();
            
            
            
            //used to retrieve the OrderID
            ResultSet rs = ps.getGeneratedKeys();
            int orderID = 0;
            if (rs.next()){
                orderID = rs.getInt(1);
            }
            
            
            
            //insert into orderdetail table
            query = "insert into orderdetail (orderID, productID, quantity) values (?,?,?) ";
            ps = connection.prepareStatement(query);
            ps.setInt(1, orderID);
            ps.setString(2, productID);
            ps.setString(3, quantity);
            System.out.println(query);
            ps.execute();
            
            
            
            //update the quantity
            query = "update product set quantity = quantity - ? where productID = ?";
            ps = connection.prepareStatement(query);
            ps.setInt(1, Integer.parseInt(quantity));
            ps.setString(2, productID);
            System.out.println(query);
            ps.execute();
            
            
            
            //commit the changes, reset the autocommit to true
            connection.commit();
            connection.setAutoCommit(true);
            
            
            
            //set label to success, clear input fields
            ad_status_label.setText("Order Successfully Completed");
            ad_customerID_textField.clear();
            ad_productID_textField.clear();
            ad_quantity_textField.clear();
            
        }catch (Exception ex){
            
            ex.printStackTrace();
            ad_status_label.setText("Error in creating your order.");
            
            
        }
        
        closeDB();
    }
    
    //return the list of employees based on the data from the database.
    public ObservableList<Employee> getEmployeeList() {
        initializeDB();
        ObservableList<Employee> employees = FXCollections.observableArrayList();

        try {
            String queryString = "select employeeID, firstName, lastName, email from employee order by employeeID ";
            ResultSet rset = stmt.executeQuery(queryString);
            while (rset.next()) {
                int employeeID = rset.getInt(1);
                String firstName = rset.getString(2);
                String lastName = rset.getString(3);
                String email = rset.getString(4);
                employees.add(new Employee(employeeID, firstName, lastName, email));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        closeDB();
        return employees;
    }

    //Displaying Customer Information
    public void displayCustomer(TextField cr_customerID_textField,
               TableView orderTable,
               Label cr_firstNameLabel,
               Label cr_lastNameLabel,
               Label cr_emailLabel){
        initializeDB();
        ObservableList<Order> orders = FXCollections.observableArrayList();
        String customerID = cr_customerID_textField.getText();
        
        try {
            
            //get data from order table
            String queryString = "select orderID, orderDate from `order` where customerID = "+customerID;
            
            PreparedStatement stmt = connection.prepareStatement(queryString);
            System.out.println(queryString);
            ResultSet rset = stmt.executeQuery(queryString);
            

            while (rset.next()) {
                int orderID = rset.getInt(1);
                String orderDate = rset.getString(2);
                orders.add(new Order(orderID, orderDate));
            }
            orderTable.setItems(orders);
            
            //Display Customer Information
            queryString = "select firstName, lastName, email from customer where customerID = "+customerID;
            stmt = connection.prepareStatement(queryString);
            System.out.println(queryString);
            rset = stmt.executeQuery(queryString);
            
            //check the first record to set the customer as the customerID should be unique.
            if (rset.next()) {
                String firstName = rset.getString(1);
                String lastName = rset.getString(2);
                String email = rset.getString(3);
                cr_firstNameLabel.setText("First Name: "+ firstName);
                cr_lastNameLabel.setText("Last Name: "+ lastName);
                cr_emailLabel.setText("Email: "+ email );
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        closeDB();
    }
    
    
    
    private void closeDB() {
        try {
            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
