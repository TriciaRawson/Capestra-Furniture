/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capestra;

//Import list
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

public class CapestraApp extends Application {

//scenes for the application
    Scene ea_scene, ac_scene, ao_scene, el_scene, cr_scene, or_scene, vp_scene;
    String employeeID;

    @Override
    public void start(Stage primaryStage) {
        employeeID="";
//Setting the title of the application
        primaryStage.setTitle("Customer Order Entry");

//Employee Account Scene Setup
        createEmployeeAccountScene(primaryStage);
    
//Add Customer  Scene Setup
        createAddCustomerScene(primaryStage);

//Add Order  Scene Setup
         createAddOrderScene(primaryStage);

//Customer Report  Scene Setup
        createEmployeeListReportScene(primaryStage);
         
//Customer Report  Scene Setup
        createCustomerReportScene(primaryStage);
        

//Order Report  Scene Setup
        createOrderReportScene(primaryStage);
        
//Product Report  Scene Setup
        createProductReportScene(primaryStage);
        
       
        primaryStage.setScene(ea_scene);
        primaryStage.show();
    }

    //Menu Setup
        public MenuBar addMenu(Stage primaryStage) {
        Menu menu1 = new Menu("Application");
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().add(menu1);
        MenuItem menu11 = new MenuItem("Employee Access");
        MenuItem menu12 = new MenuItem("Add Customer");
        MenuItem menu13 = new MenuItem("Add Order");

        Menu menu2 = new Menu("Report");
        menuBar.getMenus().add(menu2);
        MenuItem menu21 = new MenuItem("Employee List");
        MenuItem menu22 = new MenuItem("Customer List");
        MenuItem menu23 = new MenuItem("Order Report");
        MenuItem menu24 = new MenuItem("Product Report");

        menu1.getItems().addAll(menu11, menu12, menu13);
        menu2.getItems().addAll(menu21, menu22, menu23, menu24);

        menu11.setOnAction(e -> primaryStage.setScene(ea_scene));
        menu12.setOnAction(e -> primaryStage.setScene(ac_scene));
        menu13.setOnAction(e -> primaryStage.setScene(ao_scene));
        menu21.setOnAction(e -> primaryStage.setScene(el_scene));
        menu22.setOnAction(e -> primaryStage.setScene(cr_scene));
        menu23.setOnAction(e -> primaryStage.setScene(or_scene));
        menu24.setOnAction(e -> primaryStage.setScene(vp_scene));
         
        //formatting the menu bar
        menuBar.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal bold 18px 'sans-serif';");
        return menuBar;
    }
    
/****************************************
 * Methods to setup each of the screens
 * 
*****************************************/

    //Employee Account Scene Setup
    public void createEmployeeAccountScene(Stage primaryStage){
        Label ea_label1 = new Label("Employee Access");

        Label ea_employeeID_label = new Label("Employee ID");
        TextField ea_employeeID_textField = new TextField();
        ea_employeeID_textField.setPromptText("");
        ea_employeeID_textField.setMaxWidth (100);
        Button ea_button = new Button("Sign In");

        Label ea_status_label = new Label("");

        ea_button.setOnAction(e -> employeeSignIn(ea_employeeID_textField, ea_status_label));

        VBox ea_layout = new VBox(20);
        ea_layout.getChildren().addAll(addMenu(primaryStage), ea_label1, ea_employeeID_label,
        ea_employeeID_textField, ea_button, ea_status_label);
        ea_scene = new Scene(ea_layout, 800, 500);
        
        //all of the formatting pieces
         ea_label1.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         ea_employeeID_label.setStyle("-fx-text-fill:white;-fx-font: normal 15px 'sans-serif'");
         ea_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ea_employeeID_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ea_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
        
    }
    
    //Add Customer  Scene Setup
    public void createAddCustomerScene(Stage primaryStage){
        Label ac_label1 = new Label("Add Customer");

        Label ac_firstName_label = new Label("First Name");
        TextField ac_firstName_textField = new TextField();
        ac_firstName_textField.setPromptText("");
        ac_firstName_textField.setMaxWidth (200);
                
        Label ac_lastName_label = new Label("Last Name");
        TextField ac_lastName_textField = new TextField();
        ac_lastName_textField.setPromptText("");
        ac_lastName_textField.setMaxWidth (200);
        
        Label ac_address_label = new Label("Address");
        TextField ac_address_textField = new TextField();
        ac_address_textField.setPromptText("");
        ac_address_textField.setMaxWidth (400);
        
        
        Label ac_city_label = new Label("City");
        TextField ac_city_textField = new TextField();
        ac_city_textField.setPromptText("");
        ac_city_textField.setMaxWidth (200);
        
        
        Label ac_state_label = new Label("State");
        TextField ac_state_textField = new TextField();
        ac_state_textField.setPromptText("");
        ac_state_textField.setMaxWidth (100);
        
        
        Label ac_zipCode_label = new Label("Zip Code");
        TextField ac_zipCode_textField = new TextField();
        ac_zipCode_textField.setPromptText("");
        ac_zipCode_textField.setMaxWidth (100);
        
        
        Label ac_phone_label = new Label("Phone Number");
        TextField ac_phone_textField = new TextField();
        ac_phone_textField.setPromptText("");
        ac_phone_textField.setMaxWidth (200);
        
        Label ac_email_label = new Label("Email");
        TextField ac_email_textField = new TextField();
        ac_email_textField.setPromptText("");
        ac_email_textField.setMaxWidth (300);
        
        
         //label to use to display the status
        Label ac_status_label = new Label("");
         
                
         Button ac_button = new Button("Add Customer");
        ac_button.setOnAction(e -> addCustomer(ac_firstName_textField,ac_lastName_textField,
                ac_address_textField,ac_city_textField,ac_state_textField,ac_zipCode_textField,
                ac_phone_textField,ac_email_textField));

       VBox ac_layout = new VBox(20);
        ac_layout.getChildren().addAll(addMenu(primaryStage), 
                ac_label1, 
                ac_firstName_label, 
                ac_firstName_textField,
                ac_lastName_label,
                ac_lastName_textField,
                ac_address_label,
                ac_address_textField,
                ac_city_label,
                ac_city_textField,
                ac_state_label,
                ac_state_textField,
                ac_zipCode_label,
                ac_zipCode_textField,
                ac_phone_label,
                ac_phone_textField,
                ac_email_label,
                ac_email_textField,
                ac_button);
        ac_scene = new Scene(ac_layout, 800, 500);
        
        //formatting pieces
         ac_label1.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         ac_firstName_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_firstName_textField.setStyle("-fx-font: normal 20px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_lastName_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_lastName_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_address_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_address_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_city_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_city_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_state_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_state_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_zipCode_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_zipCode_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_phone_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_phone_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_email_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         ac_email_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ac_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ac_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
    }
    
//Add Order  Scene Setup
    public void createAddOrderScene(Stage primaryStage){
        Label ad_label = new Label("Add Order");
       
        Label ad_customerID_label = new Label("Customer ID");
        TextField ad_customerID_textField = new TextField();
        ad_customerID_textField.setPromptText("");
        ad_customerID_textField.setMaxWidth (100);
                
        Label ad_productID_label = new Label("Product ID");
        TextField ad_productID_textField = new TextField();
        ad_productID_textField.setPromptText("");
        ad_productID_textField.setMaxWidth (100);
        
        Label ad_quantity_label = new Label("Quantity");
        TextField ad_quantity_textField = new TextField();
        ad_quantity_textField.setPromptText("");
        ad_quantity_textField.setMaxWidth (100);
        
        
        //label to use to display the status
        Label ad_status_label = new Label("");
        
        Button ad_button = new Button("Add Order");
        ad_button.setOnAction(e -> addOrder(ad_customerID_textField,
                ad_productID_textField,
                ad_quantity_textField,
                ad_status_label));
        
        VBox ad_layout = new VBox(20);
        ad_layout.setSpacing(20);
        ad_layout.getChildren().addAll(addMenu(primaryStage), ad_label, 
                ad_customerID_label,
                ad_customerID_textField,
                ad_productID_label,
                ad_productID_textField,
                ad_quantity_label,
                ad_quantity_textField,
                ad_button,
                ad_status_label);
        ao_scene = new Scene(ad_layout, 800, 500);
        
        //formatting pieces
         ad_label.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         ad_customerID_label.setStyle("-fx-text-fill:white;-fx-font: normal 15px 'sans-serif'");
         ad_customerID_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ad_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ad_productID_label.setStyle("-fx-text-fill:white;-fx-font: normal 15px 'sans-serif'");
         ad_productID_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ad_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         ad_quantity_label.setStyle("-fx-text-fill:white;-fx-font: normal 15px 'sans-serif'");
         ad_quantity_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         ad_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
        ad_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
    }
    
    
    public void createEmployeeListReportScene(Stage primaryStage){
 
        Label el_label = new Label("Employee List");

//create the table
        TableView<Employee> employeeTable;

//create each individual column and map them to the corresponding attribute in the Employee class
        TableColumn<Employee,Integer> employeeIDColumn = new TableColumn<>("Employee ID");
        employeeIDColumn.setMinWidth(100);
        employeeIDColumn.setCellValueFactory(new PropertyValueFactory<>("Employee ID"));

        TableColumn<Employee,String> firstNameColumn = new TableColumn<>("First Name");
        firstNameColumn.setMinWidth(200);
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<Employee,String> lastNameColumn = new TableColumn<>("Last Name");
        lastNameColumn.setMinWidth(200);
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<Employee,String> emailColumn = new TableColumn<>("Email");
        emailColumn.setMinWidth(300);
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        
        TableColumn<Employee,String> UserNameColumn = new TableColumn<>("User Name");
        UserNameColumn.setMinWidth(300);
        UserNameColumn.setCellValueFactory(new PropertyValueFactory<>("UserName"));
        
        TableColumn<Employee,String> PasswordColumn = new TableColumn<>("Password");
        PasswordColumn.setMinWidth(300);
        PasswordColumn.setCellValueFactory(new PropertyValueFactory<>("Password"));
        

//set the data of the table and add in each of the columns
        employeeTable = new TableView();
        employeeTable.setItems(getEmployeeList());
        employeeTable.getColumns().addAll(employeeIDColumn,firstNameColumn,lastNameColumn,emailColumn,
        UserNameColumn,PasswordColumn);
        
        VBox el_layout = new VBox(20);
        el_layout.getChildren().addAll(addMenu(primaryStage), el_label, employeeTable);
        el_scene = new Scene(el_layout, 800, 500); 
        
       //formatting pieces
         el_label.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         employeeIDColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         firstNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         lastNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         emailColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         UserNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         PasswordColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
        el_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
         
    }
// Creates a list to set to the table
    public ObservableList<Employee> getEmployeeList(){
	ObservableList<Employee> employees = FXCollections.observableArrayList();
        CapestraDB myDB = new CapestraDB();
        employees = myDB.getEmployeeList();
        return employees;
}
    
    //Customer Report  Scene Setup
    public void createCustomerReportScene(Stage primaryStage){
    Label cr_label = new Label("Customer List");
       
        Label cr_customerId_label = new Label("Customer ID");
        TextField cr_customerId_textField = new TextField();
        cr_customerId_textField.setPromptText("");
        cr_customerId_textField.setMaxWidth (100);
        
        //create the table
        TableView<Order> customerTable;

//create each individual column and map them to the corresponding attribute in the Employee class
        TableColumn<Order,Integer> customerIdColumn = new TableColumn<>("Customer ID");
        customerIdColumn.setMinWidth(100);
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));

        TableColumn<Order,String> firstNameColumn = new TableColumn<>("First Name");
        firstNameColumn.setMinWidth(200);
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        
        TableColumn<Order,String> lastNameColumn = new TableColumn<>("Last Name");
        lastNameColumn.setMinWidth(200);
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        
        TableColumn<Order,String> addressColumn = new TableColumn<>("Address");
        addressColumn.setMinWidth(200);
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        
        TableColumn<Order,String> cityColumn = new TableColumn<>("City");
        cityColumn.setMinWidth(200);
        cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
        
        TableColumn<Order,String> stateColumn = new TableColumn<>("State");
        stateColumn.setMinWidth(200);
        stateColumn.setCellValueFactory(new PropertyValueFactory<>("state"));
        
        TableColumn<Order,String> zipCodeColumn = new TableColumn<>("Zip Code");
        zipCodeColumn.setMinWidth(200);
        zipCodeColumn.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
        
        TableColumn<Order,String> phoneColumn = new TableColumn<>("Phone");
        phoneColumn.setMinWidth(200);
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        
        TableColumn<Order,String> emailColumn = new TableColumn<>("Email");
        emailColumn.setMinWidth(200);
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        
        //set the data of the table and add in each of the columns 
        customerTable = new TableView();
        customerTable.getColumns().addAll(customerIdColumn,firstNameColumn, lastNameColumn, addressColumn,
        cityColumn,stateColumn, zipCodeColumn,phoneColumn,emailColumn);
                     
        
        Button cr_button = new Button("Customer List");
        cr_button.setOnAction(e -> primaryStage.setScene(cr_scene));
                
        
        VBox cr_layout = new VBox(20);
        cr_layout.setSpacing(20);
        cr_layout.getChildren().addAll(addMenu(primaryStage), 
                cr_label, 
                cr_customerId_label,
                cr_customerId_textField,
                cr_button,
                customerTable);
        cr_scene = new Scene(cr_layout, 800, 500);
        
        //formatting pieces
         cr_label.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         cr_customerId_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         cr_customerId_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         cr_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         customerIdColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         firstNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         lastNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         addressColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         cityColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         cityColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         stateColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         zipCodeColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         phoneColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         emailColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         cr_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
    }
    
    
    //Order Report  Scene Setup
    public void createOrderReportScene(Stage primaryStage){
    Label or_label = new Label("View Order Report");
    
     Label or_orderID_label = new Label("Order ID");
        TextField or_orderID_textField = new TextField();
        or_orderID_textField.setPromptText("");
        or_orderID_textField.setMaxWidth (100);
    
    //create the table
        TableView<Order> orderTable;
    
    //create each individual column and map them to the corresponding attribute in the Employee class
        TableColumn<Order,Integer> orderIdColumn = new TableColumn<>("Order ID");
        orderIdColumn.setMinWidth(100);
        orderIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
    
        TableColumn<Order,String> orderDateColumn = new TableColumn<>("Order Date");
        orderDateColumn.setMinWidth(200);
        orderDateColumn.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
        
        TableColumn<Order,String> productIdColumn = new TableColumn<>("Product ID");
        productIdColumn.setMinWidth(200);
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("productId"));
        
        TableColumn<Order,String> employeeIdColumn = new TableColumn<>("Employee ID");
        employeeIdColumn.setMinWidth(200);
        employeeIdColumn.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        
        TableColumn<Order,String> customerIdColumn = new TableColumn<>("Customer ID");
        customerIdColumn.setMinWidth(200);
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        
        TableColumn<Order,String> OrderDetailIDColumn = new TableColumn<>("Order Detail ID");
        OrderDetailIDColumn.setMinWidth(200);
        OrderDetailIDColumn.setCellValueFactory(new PropertyValueFactory<>("OrderDetailID")); 
    
    //set the data of the table and add in each of the columns
    orderTable = new TableView();
    orderTable.getColumns().addAll(orderIdColumn,orderDateColumn,productIdColumn,
    employeeIdColumn,customerIdColumn,OrderDetailIDColumn);
    
      Button or_button = new Button("Order Report");
      or_button.setOnAction(e -> primaryStage.setScene(or_scene));
                         
        VBox or_layout = new VBox(20);
        or_layout.setSpacing(20);
        or_layout.getChildren().addAll(addMenu(primaryStage), or_label, or_orderID_label, or_orderID_textField,
        or_button,orderTable);
        or_scene = new Scene(or_layout, 800, 500);
        
        //formatting pieces
         or_label.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         or_orderID_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         or_orderID_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         or_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         orderIdColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         orderDateColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         productIdColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         employeeIdColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         customerIdColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         OrderDetailIDColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         or_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
        
    }
    
        //Product Report  Scene Setup
    public void createProductReportScene(Stage primaryStage){
    Label vp_label = new Label("View Product Report");
    
     Label vp_productId_label = new Label("Product ID");
        TextField vp_productId_textField = new TextField();
        vp_productId_textField.setPromptText("");
        vp_productId_textField.setMaxWidth (100);
    
    //create the table
        TableView<Order> productTable;
        
     //create each individual column and map them to the corresponding attribute in the Employee class
     TableColumn<Order,Integer> productIdColumn = new TableColumn<>("Product ID");
     productIdColumn.setMinWidth(200);
     productIdColumn.setCellValueFactory(new PropertyValueFactory<>("productId")); 
     
      TableColumn<Order,String> productNameColumn = new TableColumn<>("Product Name");
      productNameColumn.setMinWidth(200);
      productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
      
      TableColumn<Order,String> CategoryIDColumn = new TableColumn<>("Category ID");
      CategoryIDColumn.setMinWidth(200);
      CategoryIDColumn.setCellValueFactory(new PropertyValueFactory<>("CategoryID"));
     
      TableColumn<Order,String> DescriptionColumn = new TableColumn<>("Description");
      DescriptionColumn.setMinWidth(200);
      DescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("Description"));
      
      TableColumn<Order,String> PriceColumn = new TableColumn<>("Price");
      PriceColumn.setMinWidth(200);
      PriceColumn.setCellValueFactory(new PropertyValueFactory<>("Price"));
      
      TableColumn<Order,String> CategoryNameColumn = new TableColumn<>("Category Name");
      CategoryNameColumn.setMinWidth(200);
      CategoryNameColumn.setCellValueFactory(new PropertyValueFactory<>("CategoryName"));
      
      TableColumn<Order,String> QuantityColumn = new TableColumn<>("Quantity Available");
      QuantityColumn.setMinWidth(200);
      QuantityColumn.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
      
     //set the data of the table and add in each of the columns
    productTable = new TableView();
    productTable.getColumns().addAll(productIdColumn,productNameColumn,CategoryIDColumn,
    CategoryNameColumn,DescriptionColumn, QuantityColumn, PriceColumn);
        
    
        Button vp_button = new Button("Product Report");
        vp_button.setOnAction(e -> primaryStage.setScene(vp_scene));
        
         
        VBox vp_layout = new VBox(20);
        vp_layout.setSpacing(20);
        vp_layout.getChildren().addAll(addMenu(primaryStage), vp_label, vp_productId_label, vp_productId_textField,
        vp_button,productTable);
        vp_scene = new Scene(vp_layout, 800, 500);
        
        
        //formatting pieces
         vp_label.setStyle("-fx-text-fill:white;-fx-font: normal bold 18px 'sans-serif'");
         vp_productId_label.setStyle("-fx-text-fill:white;-fx-font: normal 18px 'sans-serif'");
         vp_productId_textField.setStyle("-fx-font: normal 18px 'sans-serif'");
         vp_button.setStyle("-fx-background-color:black; -fx-text-fill:white; -fx-font: normal 15px 'sans-serif'");
         productIdColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         productNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         CategoryIDColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         CategoryNameColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         DescriptionColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         QuantityColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         PriceColumn.setStyle("-fx-font: normal bold 18px 'sans-serif'");
         vp_layout.setStyle("-fx-background-image:url('capestra/wood.jpg')");
        
    }
    
 /****************************************
 * Added Functionality
 * 
*****************************************/
    
    //Signing in as the employee
    public void employeeSignIn(TextField employeeID_tf, Label status_label) {
        CapestraDB myDB = new CapestraDB();
        myDB.showEmployee(employeeID_tf, status_label);
       employeeID_tf.setMaxWidth (100);
        status_label.setText("Welcome!");
       status_label.setStyle("-fx-text-fill:blue;-fx-font: normal bold 20px 'sans-serif'");
        employeeID=employeeID_tf.getText();
          
    }
    
    //adding a customer
   public void addCustomer(TextField ac_firstName_textField,TextField ac_lastName_textField,
                TextField ac_address_textField,TextField ac_city_textField,TextField ac_state_textField,TextField ac_zipCode_textField,
                TextField ac_phone_textField,TextField ac_email_textField)  {
   //add customer content with the DB
     CapestraDB myDB = new CapestraDB();
     myDB.createCustomer(ac_firstName_textField,ac_lastName_textField,
     ac_address_textField,ac_city_textField,ac_state_textField,ac_zipCode_textField,
     ac_phone_textField,ac_email_textField);
                    
     }
   
     //adding an order
      public void addOrder(TextField ad_customerID_textField,
                TextField ad_productID_textField,
                TextField ad_quantity_textField,
                Label ad_status_label) {
        //add customer content with the DB
           CapestraDB myDB = new CapestraDB();
           if (employeeID.length() == 0){
           ad_status_label.setText("Employee must sign in!");
           ad_status_label.setStyle("-fx-text-fill:red;-fx-font: normal bold 20px 'sans-serif'");
      }
           else{
                myDB.createOrder(ad_customerID_textField,
                ad_productID_textField,
                ad_quantity_textField,
                employeeID,
                ad_status_label);
                ad_status_label.setText("Thank you!");
                ad_status_label.setStyle("-fx-text-fill:blue;-fx-font: normal bold 20px 'sans-serif'");
           }
      }
        //displaying a customer
      public void displayCustomer(TextField cr_customerID_textField,
               TableView orderTable,Label cr_status_label)
               {
          CapestraDB myDB = new CapestraDB();
           if (cr_customerID_textField.getText().length() == 0){
           cr_status_label.setText("Please enter customer ID");
           cr_status_label.setStyle("-fx-text-fill:red;-fx-font: normal bold 20px 'sans-serif'");
     }
      }
                      //displaying an Order
         public void displayOrder(TextField ad_OrderID_textField,
               TableView orderTable,Label ad_status_label)
              {
          CapestraDB myDB = new CapestraDB();
           if (ad_OrderID_textField.getText().length() == 0){
          ad_status_label.setText("Please enter order ID");
           ad_status_label.setStyle("-fx-text-fill:red;-fx-font: normal bold 20px 'sans-serif'");
                }
       }
       
    public static void main(String[] args) {
        launch(args);
    }

}

